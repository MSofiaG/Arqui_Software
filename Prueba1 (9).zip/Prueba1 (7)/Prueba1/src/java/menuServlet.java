
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/menuServlet"})
@MultipartConfig
public class menuServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if (action != null) {
            switch (action.trim()) {
                case "Visualizar Productos":
                    response.sendRedirect("productos1.jsp");
                    break;
                case "Visualizar Inventario":
                    response.sendRedirect("inventario.jsp");
                    break;
                case "Servicio Tecnico":
                    response.sendRedirect("index6Cli.html");
                    break;
                case "Cerrar Sesión":
                    response.sendRedirect("index.html");
                    break;
                default:
                    response.getWriter().println("Acción no válida: " + action);
                    break;
            }
        } else {
            response.getWriter().println("No se recibió ninguna acción.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
