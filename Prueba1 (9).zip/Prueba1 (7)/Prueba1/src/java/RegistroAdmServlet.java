/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author marth
 */
@WebServlet(urlPatterns = {"/RegistroAdmServlet"})
public class RegistroAdmServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String nit = request.getParameter("nit");
        String correo = request.getParameter("correo");
        String contra = request.getParameter("contra");
        String telefono = request.getParameter("tel");
        int localidad = Integer.parseInt(request.getParameter("localidad"));

        try (Connection connection = ConexionBD.getConnection()) {
            AdministradorDAO adminDAO = new AdministradorDAO(connection);
            if (adminDAO.registrarAdministrador(nombre, apellido, nit, correo, contra, telefono, localidad)) {
                response.sendRedirect("index1Adm.html");
            } else {
                response.getWriter().println("Error al registrar el administrador.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }
}