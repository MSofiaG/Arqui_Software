import modelo.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class EmpleadoDAO {
    private Connection connection;

    public EmpleadoDAO(Connection connection) {
        this.connection = connection;
    }
    
    public boolean registrarEmpleado(String nombre, String apellido, String identificacion, String correo, String contra, String telefono) {

        String sql = "INSERT INTO empleados (nombre, apellido, identificacion, correo, contra, telefono) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nombre);
            statement.setString(2, apellido);
            statement.setString(3, identificacion);
            statement.setString(4, correo);
            statement.setString(5, contra);
            statement.setString(6, telefono);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean verificarCredenciales(String correo, String contra) {
        String sql = "SELECT COUNT(*) FROM empleados WHERE correo = ? AND contra = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, correo);
            statement.setString(2, contra);
            
            // Ejecutar la consulta y obtener el resultado
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                // Si el resultado es mayor que 0, las credenciales son correctas
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Empleado obtenerEmpleadoPorCorreo(String correo) {
    String sql = "SELECT * FROM empleados WHERE correo = ?";
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setString(1, correo);
        ResultSet rs = statement.executeQuery();
        if (rs.next()) {
            Empleado emp = new Empleado();
            emp.setNombre(rs.getString("nombre"));
            emp.setApellido(rs.getString("apellido"));
            emp.setIdentificacion(rs.getString("identificacion"));
            emp.setCorreo(rs.getString("correo"));
            emp.setCargo(rs.getString("cargo")); // Asegúrate de que el campo existe
            emp.setTipoContrato(rs.getString("tipo_contrato")); // Asegúrate también
            return emp;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}
  
    
}
