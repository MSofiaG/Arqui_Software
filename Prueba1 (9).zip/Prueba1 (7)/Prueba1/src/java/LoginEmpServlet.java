import modelo.Empleado;
import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginEmpServlet")
public class LoginEmpServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener las credenciales del formulario
        String correo = request.getParameter("correoU");
        String contra = request.getParameter("contraU");

        // Verificar las credenciales en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            EmpleadoDAO empDAO = new EmpleadoDAO(connection);
            
            // Verificar si el usuario existe
            boolean credencialesCorrectas = empDAO.verificarCredenciales(correo, contra);
           
            if (credencialesCorrectas) {
                Empleado empleado = empDAO.obtenerEmpleadoPorCorreo(correo);
                request.getSession().setAttribute("empleado", empleado);
                response.sendRedirect("panelEmpleado.jsp");
            } else {
                // Si las credenciales son incorrectas, redirigir a la misma página con un error
                response.sendRedirect("index1Emp.html?error=credenciales");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }

    @Override
    public String getServletInfo() {
        return "";
    }
}
