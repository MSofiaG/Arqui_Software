public class Queja {
    private int id;
    private String correo;
    private String mensaje;

    public Queja(int id, String correo, String mensaje) {
        this.id = id;
        this.correo = correo;
        this.mensaje = mensaje;
    }

    public int getId() {
        return id;
    }

    public String getCorreo() {
        return correo;
    }

    public String getMensaje() {
        return mensaje;
    }
}
