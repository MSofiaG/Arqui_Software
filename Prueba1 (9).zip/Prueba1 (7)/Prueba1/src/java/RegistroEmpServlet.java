/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = {"/RegistroEmpServlet"})
public class RegistroEmpServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String identificacion = request.getParameter("identificacion");
        String correo = request.getParameter("correo");
        String contra = request.getParameter("contra");
        String telefono = request.getParameter("telefono");
//        // Convertir la fecha de ingreso
//        String fechaStr = request.getParameter("fechaIngreso");
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Ajusta el patrón según tu formato
//        Date fechaIngreso = null;
//        try {
//            fechaIngreso = sdf.parse(fechaStr);
//        } catch (ParseException ex) {
//            Logger.getLogger(RegistroEmpServlet.class.getName()).log(Level.SEVERE, null, ex);
//        }
//// Convertir los parámetros numéricos
//        String salarioBaseStr = request.getParameter("salarioBase");
//        double salarioBase = (salarioBaseStr != null && !salarioBaseStr.isEmpty()) ? Double.parseDouble(salarioBaseStr) : 0.0;
//        String tipoContrato = request.getParameter("tipoContrato");
//        String bonificacionesStr = request.getParameter("bonificaciones");
//        double bonificaciones = (bonificacionesStr != null && !bonificacionesStr.isEmpty()) ? Double.parseDouble(bonificacionesStr) : 0.0;
//        String deduccionesStr = request.getParameter("deducciones");
//        double deducciones = (deduccionesStr != null && !deduccionesStr.isEmpty()) ? Double.parseDouble(deduccionesStr) : 0.0;
//        String prestacionesStr = request.getParameter("prestaciones");
//        double prestaciones = (prestacionesStr != null && !prestacionesStr.isEmpty()) ? Double.parseDouble(prestacionesStr) : 0.0;
//        String estado = request.getParameter("estado");
//        String cargo = request.getParameter("cargo");

        
        try (Connection connection = ConexionBD.getConnection()) {
            EmpleadoDAO empDAO = new EmpleadoDAO(connection);
            if (empDAO.registrarEmpleado(nombre, apellido, identificacion, correo, contra, telefono)) {
                response.sendRedirect("index1Emp.html");
            } else {
                response.getWriter().println("Error al registrar el empleado.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }
}