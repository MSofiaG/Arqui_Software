/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import com.sun.jdi.connect.spi.Connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author marth
 */
@WebServlet("/ProcesarPagoServlet")
public class ProcesarPagoServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Map<String, Map<String, Object>> carrito = (Map<String, Map<String, Object>>) session.getAttribute("carrito");

        if (carrito == null || carrito.isEmpty()) {
            response.getWriter().println("El carrito está vacío.");
            return;
        }

        String metodoPago = request.getParameter("metodoPago");
        String horario = request.getParameter("horario");

        try {
            CarritoDAO carritoDAO = new CarritoDAO();
            ProductoDAO productoDAO = new ProductoDAO();

            // Paso 1: crear el carrito en la BD
            int carritoId = carritoDAO.crearCarrito();

            // Paso 2: insertar cada producto del carrito
            for (Map.Entry<String, Map<String, Object>> entry : carrito.entrySet()) {
                int productoId = Integer.parseInt(entry.getKey());
                Map<String, Object> item = entry.getValue();
                int cantidad = (int) item.get("cantidad");

                carritoDAO.agregarProductoAlCarrito(carritoId, productoId, cantidad);
            }

            // Paso 3: limpiar el carrito de la sesión
            session.removeAttribute("carrito");

            // Obtener los productos en el carrito para pasarlos al JSP
            List<CarritoItem> carritoItems = carritoDAO.obtenerCarrito(carritoId);
            List<Producto> productos = new ArrayList<>();

            // Obtener los productos relacionados con los items del carrito
            for (CarritoItem item : carritoItems) {
                Producto producto = productoDAO.obtenerProductoPorId(item.getProductoId());
                productos.add(producto);
            }

            // Paso 4: Pasar los datos al JSP
            request.setAttribute("carritoItems", carritoItems);
            request.setAttribute("productos", productos);
            request.setAttribute("total", calcularTotal(carritoItems, productoDAO));
            request.setAttribute("metodoPago", metodoPago);
            request.setAttribute("horario", horario);
            request.setAttribute("carritoId", carritoId);

            // Redirigir al JSP de factura
            request.getRequestDispatcher("factura.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error al procesar el pago: " + e.getMessage());
        }
    }

    private double calcularTotal(List<CarritoItem> carritoItems, ProductoDAO productoDAO) throws Exception {
    double total = 0;
    for (CarritoItem item : carritoItems) {
        Producto producto = productoDAO.obtenerProductoPorId(item.getProductoId());
        
        // Convertir el precio de String a double
        double precioUnitario = Double.parseDouble(producto.getPrecio());
        
        // Multiplicamos y sumamos al total
        total += precioUnitario * item.getCantidad();
    }
    return total;
}
}



    