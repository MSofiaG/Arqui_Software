import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/RegistroCliServlet"})
public class RegistroCliServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String nit = request.getParameter("nit");
        String correo = request.getParameter("correo");
        String contra = request.getParameter("contra"); // Deberías hacer un hash de la contraseña aquí
        String telefono = request.getParameter("tel");
        int localidad = Integer.parseInt(request.getParameter("localidad"));

        // Guardar en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            ClienteDAO clienteDAO = new ClienteDAO(connection);
            if (clienteDAO.registrarCliente(nombre, apellido, nit, correo, contra, telefono, localidad)) {
                response.sendRedirect("index3Cli.html");  // Redirigir a la página de inicio de sesión
            } else {
                response.getWriter().println("Error al registrar el cliente.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }
}
