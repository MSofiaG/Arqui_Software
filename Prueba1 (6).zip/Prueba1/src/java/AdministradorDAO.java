import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdministradorDAO {
    private Connection connection;

    public AdministradorDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean registrarAdministrador(String nombre, String apellido, String nit, String correo, String contra, String telefono, int localidad) {
        String sql = "INSERT INTO administradores (nombre, apellido, nit, correo, contra, telefono, localidad) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nombre);
            statement.setString(2, apellido);
            statement.setString(3, nit);
            statement.setString(4, correo);
            statement.setString(5, contra);
            statement.setString(6, telefono);
            statement.setInt(7, localidad);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
