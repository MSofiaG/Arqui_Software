import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// Asegúrate de tener estas clases importadas
// import tu.paquete.CarritoDAO;
// import tu.paquete.CarritoItem;

@WebServlet("/CarritoServlet")
public class CarritoServlet extends HttpServlet {
    
    private CarritoDAO carritoDAO;

    @Override
    public void init() {
        carritoDAO = new CarritoDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("agregar".equals(action)) {
            agregarProductoAlCarrito(request, response);
        } else if ("pagar".equals(action)) {
            procesarPago(request, response);
        }
    }

    // Método para agregar un producto al carrito
    private void agregarProductoAlCarrito(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession();

        // Verificar que el carritoId esté disponible en la sesión
        Integer carritoId = (Integer) session.getAttribute("carritoId");
        if (carritoId == null) {
            carritoId = crearNuevoCarrito(session); // Método opcional para crear un carrito si no existe
        }

        int productoId = Integer.parseInt(request.getParameter("productoId"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));
        
        // Agregar producto al carrito en la base de datos
        carritoDAO.agregarProductoAlCarrito(carritoId, productoId, cantidad);
        response.sendRedirect("verCarrito.jsp"); // Redirige al usuario a la página del carrito
    }

    // Método para procesar el pago y guardar los datos del carrito en la base de datos
    private void procesarPago(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        HttpSession session = request.getSession();
        Integer carritoId = (Integer) session.getAttribute("carritoId");
        
        if (carritoId == null) {
            response.sendRedirect("verCarrito.jsp?error=carritoNoEncontrado");
            return;
        }

        try {
            List<CarritoItem> carrito = carritoDAO.obtenerCarrito(carritoId);
            
            // Verifica si hay stock suficiente antes de confirmar el pago
            for (CarritoItem item : carrito) {
                if (!hayStockSuficiente(item.getProductoId(), item.getCantidad())) {
                    response.sendRedirect("verCarrito.jsp?error=stockInsuficiente");
                    return;
                }
            }
            
            // Guardar los items del carrito en la tabla carritoItem
            carritoDAO.guardarCarrito(carrito, carritoId);
            
            response.sendRedirect("procesarPago.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error al procesar el pago.");
        }
    }

    // Método de utilidad para verificar stock (simulado para el ejemplo)
    private boolean hayStockSuficiente(int productoId, int cantidadSolicitada) {
        // Aquí se implementaría la lógica de consulta a la base de datos para verificar el stock
        return true; // Placeholder; este valor se debería obtener de la base de datos
    }

    // Método opcional para crear un carrito nuevo si no existe uno en la sesión
    private int crearNuevoCarrito(HttpSession session) {
        int nuevoCarritoId = carritoDAO.crearCarrito(); // Método en CarritoDAO para crear un carrito en la BD
        session.setAttribute("carritoId", nuevoCarritoId);
        return nuevoCarritoId;
    }
}
