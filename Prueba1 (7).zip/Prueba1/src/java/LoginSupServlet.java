import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginSupServlet")
public class LoginSupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener las credenciales del formulario
        String correo = request.getParameter("correoU");
        String contra = request.getParameter("contraU");

        // Verificar las credenciales en la base de datos
        try (Connection connection = ConexionBD.getConnection()) {
            SupermercadoDAO supermercadoDAO = new SupermercadoDAO(connection);
            
            // Verificar si el supermercado existe
            boolean credencialesCorrectas = supermercadoDAO.verificarCredenciales(correo, contra);
            
            if (credencialesCorrectas) {
                // Redirigir a la página de administración del supermercado
                response.sendRedirect("index3Sup.html");
            } else {
                // Si las credenciales son incorrectas, redirigir a la misma página con un error
                response.sendRedirect("index1Sup.html?error=credenciales");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error en la conexión a la base de datos.");
        }
    }

    @Override
    public String getServletInfo() {
        return "Login servlet para supermercados.";
    }
}
