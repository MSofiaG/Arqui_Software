import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/productos_db?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "DanteG19";

    // Método para agregar un producto
    public void agregarProducto(Producto producto) {
        String sql = "INSERT INTO productos (nombre, descripcion, fecha_vencimiento, tipo, precio, cantidad, foto, marca) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, producto.getNombre());
            statement.setString(2, producto.getDescripcion());
            statement.setString(3, producto.getFechaVencimiento());
            statement.setString(4, producto.getTipo());
            statement.setString(5, producto.getPrecio());
            statement.setString(6, producto.getCantidad());
            statement.setString(7, producto.getFoto());
            statement.setString(8, producto.getMarca());

            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al agregar el producto: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para modificar un producto por ID
    public void modificarProducto(Producto producto) {
        String sql = "UPDATE productos SET nombre = ?, descripcion = ?, fecha_vencimiento = ?, tipo = ?, precio = ?, cantidad = ?, foto = ?, marca = ?, WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, producto.getNombre());
            statement.setString(2, producto.getDescripcion());
            statement.setString(3, producto.getFechaVencimiento());
            statement.setString(4, producto.getTipo());
            statement.setString(5, producto.getPrecio());
            statement.setString(6, producto.getCantidad());
            statement.setString(7, producto.getFoto());
            statement.setString(8, producto.getMarca());
            statement.setInt(9, producto.getId());

            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al modificar el producto con ID " + producto.getId() + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para eliminar un producto por ID
    public void eliminarProducto(int productId) {
        String sql = "DELETE FROM productos WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, productId);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error al eliminar el producto con ID " + productId + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Método para obtener todos los productos disponibles
    public List<Producto> obtenerTodosLosProductos() {
        List<Producto> productos = new ArrayList<>();
        String sql = "SELECT id, nombre, descripcion, fecha_vencimiento, tipo, precio, cantidad, foto, marca FROM productos";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Producto producto = new Producto();
                producto.setId(rs.getInt("id"));
                producto.setNombre(rs.getString("nombre"));
                producto.setDescripcion(rs.getString("descripcion"));
                producto.setFechaVencimiento(rs.getString("fecha_vencimiento"));
                producto.setTipo(rs.getString("tipo"));
                producto.setPrecio(rs.getString("precio"));
                producto.setCantidad(rs.getString("cantidad"));
                producto.setFoto(rs.getString("foto"));
                producto.setMarca(rs.getString("marca"));
                productos.add(producto);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los productos: " + e.getMessage());
            e.printStackTrace();
        }
        return productos;
    }

    // Método para obtener productos por tipo (categoría)
    public List<Producto> obtenerProductosPorTipo(String tipo) {
        List<Producto> productos = new ArrayList<>();
        String sql = "SELECT id, nombre, descripcion, fecha_vencimiento, tipo, precio, cantidad, foto, marca FROM productos WHERE tipo = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, tipo);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    Producto producto = new Producto();
                    producto.setId(rs.getInt("id"));
                    producto.setNombre(rs.getString("nombre"));
                    producto.setDescripcion(rs.getString("descripcion"));
                    producto.setFechaVencimiento(rs.getString("fecha_vencimiento"));
                    producto.setTipo(rs.getString("tipo"));
                    producto.setPrecio(rs.getString("precio"));
                    producto.setCantidad(rs.getString("cantidad"));
                    producto.setFoto(rs.getString("foto"));
                    producto.setMarca(rs.getString("marca"));
                    productos.add(producto);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener productos del tipo " + tipo + ": " + e.getMessage());
            e.printStackTrace();
        }
        return productos;
    }
}
