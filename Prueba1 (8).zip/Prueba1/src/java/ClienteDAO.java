import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClienteDAO {
    private Connection connection;

    public ClienteDAO(Connection connection) {
        this.connection = connection;
    }

    // Método para registrar un nuevo cliente
    public boolean registrarCliente(String nombre, String apellido, String nit, String correo, String contra, String telefono, int localidad) {
        String sql = "INSERT INTO clientes (nombre, apellido, nit, correo, contra, telefono, localidad) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, nombre);
            statement.setString(2, apellido);
            statement.setString(3, nit);
            statement.setString(4, correo);
            statement.setString(5, contra); // Deberías almacenar el hash de la contraseña aquí
            statement.setString(6, telefono);
            statement.setInt(7, localidad);
            statement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para verificar las credenciales del cliente
    public boolean verificarCredenciales(String correo, String contra) {
    String sql = "SELECT COUNT(*) FROM clientes WHERE correo = ? AND contra = ?";
    
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setString(1, correo);
        statement.setString(2, contra);  // Aquí deberías comparar el hash si usas hashing
        ResultSet resultSet = statement.executeQuery();
        
        // Si se encuentra un registro, el usuario existe
        if (resultSet.next()) {
            if (resultSet.getInt(1) > 0) {
                return true;
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return false;
}

}
