import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(urlPatterns = {"/miServlet3"})
@MultipartConfig
public class miServlet3 extends HttpServlet {

    // Instanciación del ProductoDAO
    private final ProductoDAO productoDAO = new ProductoDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "Publicar":
                    publicarProducto(request, response);
                    break;
                case "Modificar":
                    modificarProducto(request, response);
                    break;
                case "Eliminar":
                    eliminarProducto(request, response);
                    break;
                default:
                    response.getWriter().println("Acción no válida.");
                    break;
            }
        } else {
            response.getWriter().println("Acción no proporcionada.");
        }
    }

    private void publicarProducto(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // Obtener los parámetros del formulario
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String fechaVencimiento = request.getParameter("fechaVencimiento");
        String tipo = request.getParameter("producto");
        String precio = request.getParameter("precio");
        String cantidad = request.getParameter("cantidad");

        // Manejo del archivo subido
        Part fotoPart = request.getPart("foto");
        String nombreArchivo = Paths.get(fotoPart.getSubmittedFileName()).getFileName().toString();

        String marca = request.getParameter("marca");
        // Ruta de la carpeta "imagenes" en el proyecto
        String rutaCarpeta = getServletContext().getRealPath("/") + "imagenes";
        File carpeta = new File(rutaCarpeta);
        if (!carpeta.exists()) {
            carpeta.mkdir(); // Crear la carpeta si no existe
        }
        String rutaArchivo = rutaCarpeta + File.separator + nombreArchivo;
        fotoPart.write(rutaArchivo); // Guardar el archivo

        // Crear el objeto Producto con los datos recibidos del formulario
        Producto producto = new Producto(nombre, descripcion, fechaVencimiento, tipo, precio, cantidad, nombreArchivo, marca);

        // Llamar al ProductoDAO para agregar el producto a la base de datos
        productoDAO.agregarProducto(producto);

        // Redirigir a la página correspondiente
        response.sendRedirect("index_4.jsp");
    }

    private void modificarProducto(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // Obtener los parámetros del formulario y validar
        String productId = request.getParameter("selectedRowId");
        String nuevoNombre = request.getParameter("modificarNombre");
        String nuevaDescripcion = request.getParameter("modificarDescripcion");
        String nuevaFecha = request.getParameter("modificarFecha");
        String nuevoTipo = request.getParameter("modificarTipo");
        String nuevoPrecio = request.getParameter("modificarPrecio");
        String nuevaCantidad = request.getParameter("modificarCantidad");
        String nuevaMarca = request.getParameter("modificarMarca");

        if (productId != null && nuevoNombre != null && nuevaDescripcion != null && nuevaFecha != null && nuevoTipo != null && nuevoPrecio != null && nuevaCantidad != null && nuevaMarca != null) {
            try {
                // Convertir el productId a int
                int id = Integer.parseInt(productId);

                // Crear el objeto Producto con los datos actualizados
                Producto producto = new Producto(id, nuevoNombre, nuevaDescripcion, nuevaFecha, nuevoTipo, nuevoPrecio, nuevaCantidad, nuevaMarca, null); // null para la foto

                // Llamar al ProductoDAO para modificar el producto en la base de datos
                productoDAO.modificarProducto(producto);

                // Redirigir a la página correspondiente (index_4.jsp)
                response.sendRedirect("index4Sup.html");
            } catch (NumberFormatException e) {
                response.getWriter().println("Error: El ID del producto no es válido.");
            }
        } else {
            response.getWriter().println("Faltan parámetros para modificar el producto.");
        }
    }

    private void eliminarProducto(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        // Obtener el ID del producto a eliminar
        String productId = request.getParameter("selectedRowId");

        if (productId != null) {
            // Convertir el productId a int
            int id = Integer.parseInt(productId);

            // Llamar al ProductoDAO para eliminar el producto de la base de datos
            productoDAO.eliminarProducto(id);

            // Redirigir a la página correspondiente (index_4.jsp)
            response.sendRedirect("index_4.jsp");
        } else {
            response.getWriter().println("Faltó el ID del producto para eliminar.");
        }
    }
}
