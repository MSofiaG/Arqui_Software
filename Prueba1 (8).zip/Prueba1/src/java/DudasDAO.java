import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DudasDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/productos_db?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "DanteG19";

    // Método para guardar una queja en la base de datos
    public void guardarQueja(String nombre, String mensaje) {
        // Consulta SQL para insertar una nueva queja
        String sql = "INSERT INTO quejas (nombre, mensaje) VALUES (?, ?)";

        try {
            // Establecer la conexión a la base de datos
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
                 // Preparar la consulta SQL
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                // Establecer los valores de los parámetros de la consulta
                statement.setString(1, nombre);
                statement.setString(2, mensaje);

                // Ejecutar la consulta de inserción
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            // Manejar errores de SQL
            e.printStackTrace();
            throw new RuntimeException("Error al guardar la queja", e);
        }
    }
}
